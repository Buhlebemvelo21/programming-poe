﻿using Microsoft.VisualBasic.FileIO;
using Programming_POE;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Controls.Primitives;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Xml.Linq;

namespace Programming_POE
public class Recipe
{
    public string Name { get; set; }
    public List<string> Ingredients { get; set; }
    public string FoodGroup { get; set; }
    public int Calories { get; set; }
}
List<Recipe> recipe = new List<Recipe>();
public List<Recipe> FilterRecipes (string ingredient, string foodGroup, int maxCalories)
{
    return recipes
        .Where(r => string.IsNullOrEmpty(ingredient) || r.Ingredients.Contains(ingredient))
        .Where(r => string.IsNullOrEmpty(foodGroup) || r.FoodGroup == foodGroup)
        .Where(r => maxCalories == 0 || r.Calories <= maxCalories)
        .ToList();
}

string ingredientInput = "tomato";
string foodGroupInput = "vegetables";
int maxCaloriesInput = 500;

List<Recipe> filteredRecipes = FilterRecipes(ingredientInput, foodGroupInput, maxCaloriesInput);
