﻿using Programming_POE;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Programming_POE
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public List<Recipe> RecipeList { get; set; } 


        public string[] foodgroup { get; set; }
        public int[] calories { get; set; }
        public string[] ingredients { get; set; }
        public MainWindow()
        {
            InitializeComponent();
            RecipeList = new List<Recipe>
            {
            Recipe recipes = new Recipe();
            foodgroup = new string[] { "FoodG1", "FoodG2", "FoodG3" };
            calories = new int[] { 500, 800, 600 };
            ingredients = new string[] { "Recipe1", "Recipe2", "Recipe3" };



            DataContext = this;
        }
        private void Calories_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void button_Click(object sender, RoutedEventArgs e)
        {


        }

        private void button_Click_1(object sender, RoutedEventArgs e)
        {


        }

        private void Ingredients_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Calories_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void AddBtn_Click(object sender, RoutedEventArgs e)
        {
            Ingredients.Items.Clear();
            Ingredients.Items.Add("Recipe1");
            Ingredients.Items.Add("Recipe2");
            Ingredients.Items.Add("Recipe3");
            Ingredients.Text = "Select from...";
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            Calories.Items.Clear();
            Calories.Items.Add(500);
            Calories.Items.Add(600);
            Calories.Items.Add(800);
            Calories.Text = "Select from...";
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            FoodGroup.Items.Clear();
            FoodGroup.Items.Add("FoodG1");
            FoodGroup.Items.Add("FoodG2");
            FoodGroup.Items.Add("FoodG3");
            FoodGroup.Text = "Select from...";
        }

        private void listBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
