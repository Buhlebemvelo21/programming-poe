﻿using PROG_Task1;
using System.Threading.Tasks;
 
namespace PROG_Task1;
class Recipe
    {

    private string[] NumOfIngredients { get; set; }
    private double[] quantity { get; set; }
    private string[] unitOfmeasurement { get; set; }
    private string[] NumberOfSteps { get; set; }
    public string Name { get; set; }
    public List<IngredientsUsed> ingredients { get; set; }
    public List<NumberOfSteps> steps { get; set; }
    public int TotalCalories { get; set; }

    public string Foodgroup { get; set; }
    public Recipe(string[] NumOfIngredients, double quantity, string unitOfmeasurement, string name, List<IngredientsUsed> ingredients, List<NumberOfSteps> steps)
    {
        Name = name;
        this.NumOfIngredients = NumOfIngredients;
        NumberOfSteps = NumberOfSteps;
        TotalCalories = CalculateTotalCalories();
    }

    public Recipe() { 
    }

    private int CalculateTotalCalories()
    {
        int totalCalories = 0;
        foreach (IngredientsUsed ingredient in ingredients)
        {
            totalCalories += ingredient.Calories1;
        }
        return totalCalories;
    }
}

class RecipeManager
{
    private List<Recipe> recipes;

    public RecipeManager()
    {
        recipes = new List<Recipe>();
    }

    public void AddTheRecipe(Recipe recipe)
    {
        recipes.Add(recipe);
    }

    public void RemoveTheRecipe(Recipe recipe)
    {
        recipes.Remove(recipe);
    }

    public void ScaleRecipe( Recipe recipe)
    {
        
    }

    public List<Recipe> GetList()
    {
        return recipes;
    }

    public Recipe GetRecipeName(string name)
    {
        foreach (Recipe recipe in recipes)
        {
            if (recipe.Name == name)
            {
                return recipe;
            }
        }
        return null;
    }
}
class UI
{
    private RecipeManager recipeManager;

    public UI()
    {
        recipeManager = new RecipeManager();
    }

    public void Run()
    {
        Recipe recipe = new Recipe();
        bool exit = false;
        while (!exit)
        {
            Console.WriteLine("Welcome to Recipe Manager!");
            Console.WriteLine("Please choose an option:");
            Console.WriteLine("1. Add a recipe");
            Console.WriteLine("2. Remove a recipe");
            Console.WriteLine("3. Display recipe list");
            Console.WriteLine("4. Display recipe details");
            Console.WriteLine("5. Scale recipe");
            Console.WriteLine("6. Reset recipe quantities");
            Console.WriteLine("7. Clear all data");
            Console.WriteLine("8. Exit");

            int choice = 0;
            int.Parse(Console.ReadLine());

            switch (choice)
            {
                case "1":
                    AddTheRecipe();

                    break;
                case "2":
                    DisplayRecipe();
                    break;
                case "3":
                    ScaleRecipe();

                    Console.Write("ENTER YOUR SCALE (0.5, 2, or 3): ");
                    double factor = double.Parse(Console.ReadLine());
                    recipe.ScaleRecipe(factor);
                    break;
                case "4":
                    ResetQuantities();
                    break;
                case "5":
                    AddRecipes();
                    break;

                case "6":
                    RemoveRecipes();
                    break;

                case "7":
                    GetRecipeList();
                    break;

                case "8":
                    ClearAllData();
                    break;

                case "9":
                    exit = true;
                    break;
                default:
                    Console.WriteLine("INVALID CHOICE!!!!!!");
                    break;
            }
            Console.WriteLine();
        }
    }






    public static void Main(string[] args)
    {
        const int MAX = 10;

        IngredientsUsed[] ingre = new IngredientsUsed[MAX];
        NumberOfSteps[] st = new NumberOfSteps[MAX];

        int n;
        string confirm;

       Console.WriteLine("NUMBER OF INGREDIENTS USED?");
        n = int.Parse(Console.ReadLine());

        for (int i = 0; i < MAX; i++)
        {
            ingre[i] = new IngredientsUsed();
            st[i] = new NumberOfSteps();

            Console.WriteLine("PLEASE ENTER NUMBER OF INGREDIENTS USED ");
            ingre[i].NumOfIngredients = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("PLEASE ENTER NAME OF INGREDIENTS USED ");
            ingre[i].Name = Console.ReadLine();

            Console.WriteLine("PLEASE ENTER THE QUANTITY USED IN THE RECIPE ");
            ingre[i].Quantity = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("PLEASE ENTER UNIT OF MEASUREMENTS USED ");
            ingre[i].UnitOfmeasurement = Console.ReadLine();

            Console.WriteLine("PLEASE ENTER NUMBER OF STEPS USED ");
            st[i].NumOfSteps = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("PLEASE DESCRIBE  EACH STEPS MENTIONED ");
            st[i].Description = Console.ReadLine();

            Console.Write("PLEASE ENTER THE SCALE FACTOR (0.5, 2, or 3) ");
            double factor = double.Parse(Console.ReadLine());

            for (int j = 0; j < NumOfIngredients; j++)
            {
                ingre[j].Quantity *= factor;
            }
            for (int j = 0; j < NumOfIngredients; j++)
            {
                ingre[j].Quantity /= 2;
            }
            Console.WriteLine("WOULD YOU LIKE THE RECIPE TO BE CLEARED ? YES OR NO");
            confirm = Console.ReadLine().ToString();

            if (confirm == "YES")
            {
                Console.Clear();
            }
            else
            {
                Console.WriteLine("Information is not cleared");
            }
        }
    }
}

/*// See https://aka.ms/new-console-template for more information
using PROG_Task1;

Console.WriteLine("Hello, World!");*/