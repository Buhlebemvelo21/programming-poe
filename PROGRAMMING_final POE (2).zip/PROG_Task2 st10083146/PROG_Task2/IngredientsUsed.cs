﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROG_Task1
{
    class IngredientsUsed
    {
        private int numOfIngredients;
        private string name;
        private double quantity;
        private string unitOfmeasurement;
        private string Foodgroup;
        private int Calories;

        public IngredientsUsed(int numOfIngredients, string name, double quantity, string unitOfmeasurement, string foodgroup, int calories)
        {
            this.NumOfIngredients = numOfIngredients;
            this.Name = name;
            this.Quantity = quantity;
            this.UnitOfmeasurement = unitOfmeasurement;
            Foodgroup1 = foodgroup;
            Calories1 = calories;
        }

        public int NumOfIngredients { get => numOfIngredients; set => numOfIngredients = value; }
        public string Name { get => name; set => name = value; }
        public double Quantity { get => quantity; set => quantity = value; }
        public string UnitOfmeasurement { get => unitOfmeasurement; set => unitOfmeasurement = value; }
        public string Foodgroup1 { get => Foodgroup; set => Foodgroup = value; }
        public int Calories1 { get => Calories; set => Calories = value; }
    }
}




        