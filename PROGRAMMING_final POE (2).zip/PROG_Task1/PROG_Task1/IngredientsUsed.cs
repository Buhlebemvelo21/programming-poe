﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROG_Task1
{
    class IngredientsUsed
    {
        private int numOfIngredients;
        private string name;
        private double quantity;
        private string unitOfmeasurement;

        public IngredientsUsed()
        {
        }

        public IngredientsUsed(int numOfIngredients, string name, double quantity, string unitOfmeasurement)
        {
            this.NumOfIngredients = numOfIngredients;
            this.Name = name;
            this.Quantity = quantity;
            this.UnitOfmeasurement = unitOfmeasurement;
        }

        public int NumOfIngredients { get => numOfIngredients; set => numOfIngredients = value; }
        public int NumberOfIngredients { get; }
        public string Name { get => name; set => name = value; }
        public double Quantity { get => quantity; set => quantity = value; }
        public string UnitOfmeasurement { get => unitOfmeasurement; set => unitOfmeasurement = value; }
    }
}

