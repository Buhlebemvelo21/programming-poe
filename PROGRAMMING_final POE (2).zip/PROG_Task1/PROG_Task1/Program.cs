﻿using PROG_Task1;
using System.Threading.Tasks;
 
class Program
{
    public static int NumOfIngredients { get; private set; }


    public static void Main(string[] args)
    {
        const int MAX = 10;

        IngredientsUsed[] ingre = new IngredientsUsed[MAX];
        NumberOfSteps[] st = new NumberOfSteps[MAX];

        int n;
        string confirm;

       /* Console.WriteLine("NUMBER OF INGREDIENTS USED?");
        n = int.Parse(Console.ReadLine());*/

        for (int i = 0; i < MAX; i++)
        {
            ingre[i] = new IngredientsUsed();
            st[i] = new NumberOfSteps();

            Console.WriteLine("PLEASE ENTER NUMBER OF INGREDIENTS USED ");
            ingre[i].NumOfIngredients = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("PLEASE ENTER NAME OF INGREDIENTS USED ");
            ingre[i].Name = Console.ReadLine();

            Console.WriteLine("PLEASE ENTER THE QUANTITY USED IN THE RECIPE ");
            ingre[i].Quantity = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("PLEASE ENTER UNIT OF MEASUREMENTS USED ");
            ingre[i].UnitOfmeasurement = Console.ReadLine();

            Console.WriteLine("PLEASE ENTER NUMBER OF STEPS USED ");
            st[i].NumOfSteps = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("PLEASE DESCRIBE  EACH STEPS MENTIONED ");
            st[i].Description = Console.ReadLine();

            Console.Write("PLEASE ENTER THE SCALE FACTOR (0.5, 2, or 3) ");
            double factor = double.Parse(Console.ReadLine());

            for (int j = 0; j < NumOfIngredients; j++)
            {
                ingre[j].Quantity *= factor;
            }
            for (int j = 0; j < NumOfIngredients; j++)
            {
                ingre[j].Quantity /= 2;
            }
            Console.WriteLine("WOULD YOU LIKE THE RECIPE TO BE CLEARED ? YES OR NO");
            confirm = Console.ReadLine().ToString();

            if (confirm == "YES")
            {
                Console.Clear();
            }
            else
            {
                Console.WriteLine("Information is not cleared");
            }
        }
    }
}

/*// See https://aka.ms/new-console-template for more information
using PROG_Task1;

Console.WriteLine("Hello, World!");*/