﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROG_Task1
{
    class NumberOfSteps
    {
        private int numOfsteps;
        private string description;

        public NumberOfSteps()
        {

        }

        public NumberOfSteps(int numOfsteps, string description)
        {
            this.NumOfSteps = numOfsteps;
            this.Description = description;
        }

        public int NumOfSteps { get => numOfsteps; set => numOfsteps = value; }
        public string Description { get => description; set => description = value; }
    }
}
